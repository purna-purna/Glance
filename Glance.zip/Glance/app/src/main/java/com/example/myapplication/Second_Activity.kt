package com.example.glance_application

import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import com.example.myapplication.R

class Second_Activity : AppCompatActivity() {
    private lateinit var powerButtonReceiver: PowerButtonReceiver
    private lateinit var imageView: ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        imageView=findViewById(R.id.imageView)
        powerButtonReceiver = PowerButtonReceiver(imageView)

    }
    override fun onResume() {
        super.onResume()
        // Register the BroadcastReceiver to listen for power button events
        val filter = IntentFilter()
        filter.addAction(Intent.ACTION_SCREEN_ON)
        filter.addAction(Intent.ACTION_SCREEN_OFF)
        registerReceiver(powerButtonReceiver, filter)
    }

    override fun onPause() {
        super.onPause()
        // Unregister the BroadcastReceiver when the activity is paused
        unregisterReceiver(powerButtonReceiver)
    }


}