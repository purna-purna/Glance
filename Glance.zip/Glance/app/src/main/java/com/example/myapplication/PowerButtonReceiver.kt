package com.example.glance_application

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.ImageView
import com.example.myapplication.R

class PowerButtonReceiver(private val imageView: ImageView) : BroadcastReceiver() {

    private var imageIndex = 1
    private val images = arrayOf(
        R.drawable.image1,
        R.drawable.image2,
        R.drawable.image3
    )

    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == Intent.ACTION_SCREEN_ON) {
            Log.d("PowerButtonReceiver", "Screen is ON")

            // Power button is pressed to turn screen on
            updateImage()
        } else if (intent?.action == Intent.ACTION_SCREEN_OFF) {
            Log.d("PowerButtonReceiver", "Screen is OFF")

            // Power button is pressed to turn screen off
            updateImage()
        }
    }

    private fun updateImage() {
        imageView.setImageResource(images[imageIndex % images.size])
        imageIndex++
    }
}
