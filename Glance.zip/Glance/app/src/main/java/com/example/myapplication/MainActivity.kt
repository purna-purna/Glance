package com.example.myapplication

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.view.View
import androidx.annotation.RequiresApi
import androidx.viewpager2.widget.ViewPager2
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var viewPager: ViewPager2
    private lateinit var imageAdapter: ImageAdapter
    private val images = listOf(
        R.drawable.image1,
        R.drawable.image2,
        R.drawable.image3,
        R.drawable.image4
    )

    private var currentPage = 0
    private val handler = Handler()




    private var isServiceBound = false
    private var foregroundService: MyForegroundService? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as MyForegroundService.LocalBinder
            foregroundService = binder.getService()
            isServiceBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isServiceBound = false
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val serviceIntent = Intent(this, MyForegroundService::class.java)
        bindService(serviceIntent, connection, Context.BIND_AUTO_CREATE)


        viewPager = findViewById(R.id.viewPager)
        imageAdapter = ImageAdapter(images)
        viewPager.adapter = imageAdapter

        val update = Runnable {
            if (currentPage == images.size) {
                currentPage = 0
            }
            viewPager.currentItem = currentPage++
        }

        val timer = Timer()
        timer.schedule(object : TimerTask() {
            override fun run() {
                handler.post(update)
            }
        }, 3000, 3000) // Delay 3s, repeat every 3s
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun Service(view: View) {
//        val serviceIntent = Intent(this, MyForegroundService::class.java)
//        startForegroundService(serviceIntent)

        if (isServiceBound) {
            foregroundService?.startMusic()
        }
    }

    fun StopMusic(view: View) {
//        val serviceIntent = Intent(this, MyForegroundService::class.java)
//        onDestroy(serviceIntent)
        if (isServiceBound) {
            foregroundService?.stopMusic()
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        if (isServiceBound) {
            unbindService(connection)
            isServiceBound = false
        }
    }
}